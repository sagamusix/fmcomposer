void lang_load(const char* filename);

const char* lang(const char* section, const char* key);