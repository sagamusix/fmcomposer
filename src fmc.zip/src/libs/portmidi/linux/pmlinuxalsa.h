/* pmlinuxalsa.h -- system-specific definitions */

PmError pm_linuxalsa_init(void);
void pm_linuxalsa_term(void);


