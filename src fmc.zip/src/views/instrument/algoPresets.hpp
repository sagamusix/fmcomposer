#ifndef ALGOPRESETS_H
#define ALGOPRESETS_H

#include "../../gui/gui.hpp"

void loadAlgoPreset(int id, Operator* fmop, Operator* outs);

#endif