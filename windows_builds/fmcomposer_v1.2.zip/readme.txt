   _____ _ _ _      __
    /  '' ) ) )    /  )
 ,-/-,   / / /    /   __ ______  _   __ _   _  __ 
(_/     / ' (_   (__/(_)/ / / <_/_)_(_)/_)_</_/ (_
                               / 
                              '  v1.1 (31-01-2018)

     by St�phane Damo -- http://fmcomposer.org


***  Thank you for downloading FM Composer ***


Recommended setup :

	- Windows 10 / 8 / 7
	- A full HD screen
	- Core i3 CPU or equivalent


Lowest tested, fully working setup :

	- Windows XP SP3
	- 1366*768 screen
	- Pentium III 933 Mhz
	- 256 MB RAM


This software is free and contains no ads nor intrusive features.


*** Credits ***

	- Masami Komuro (demo song and some FM sounds)
	- Klairzaki Fil-Xter (quality testing)

	- Laurent Gomila & contributors (SFML lib)
	- Guillaume Vareille (tinyfiledialogs lib)
	- Brodie Thiesfield (SimpleIni lib)
 	- Ross Bencina/Phil Burk/Roger B. Dannenberg (PortMidi/Audio lib)
	- Yann Collet (LZ4 lib)
	- The LAME MP3 encoder team
 	- The Google team (Material Icons)

*** Changelog ***

v1.1
	- [Feature] Added some new demo songs, mostly from imported MIDIs
	- [Fix] Crash on Undo action under certain circumstances 
	- [Fix] Pattern list was selected on mouse release even if it wasn't focused
	- [Fix] small 1-frame graphical glitch when scrolling in pattern list

v1.2
	- [Fix] 'Remove rows' function did nothing
	- [Fix] Small click noise occured on the next note after a channel was unmuted
	- [Fix] Recent songs menu width not immediately updated
	- [Fix] Blurry pattern top (channel params)