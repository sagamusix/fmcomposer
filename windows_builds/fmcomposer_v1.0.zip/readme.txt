   _____ _ _ _      __
    /  '' ) ) )    /  )
 ,-/-,   / / /    /   __ ______  _   __ _   _  __ 
(_/     / ' (_   (__/(_)/ / / <_/_)_(_)/_)_</_/ (_
                               / 
                              '  v1.0 (30-01-2018)

     by St�phane Damo -- http://fmcomposer.org


***  Thank you for downloading FM Composer ***


Recommended setup :

	- Windows 10 / 8 / 7
	- A full HD screen
	- Core i3 CPU or equivalent


Lowest tested, fully working setup :

	- Windows XP SP3
	- 1366*768 screen
	- Pentium III 933 Mhz
	- 256 MB RAM


This software is free and contains no ads nor intrusive features.


*** Credits ***

	- Masami Komuro (demo song and some FM sounds)
	- Klairzaki Fil-Xter (quality testing)

	- Laurent Gomila & contributors (SFML lib)
	- Guillaume Vareille (tinyfiledialogs lib)
	- Brodie Thiesfield (SimpleIni lib)
 	- Ross Bencina/Phil Burk/Roger B. Dannenberg (PortMidi/Audio lib)
	- Yann Collet (LZ4 lib)
	- The LAME MP3 encoder team
 	- The Google team (Material Icons)